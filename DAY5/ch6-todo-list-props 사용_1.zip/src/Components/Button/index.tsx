import React from 'react';
import Styled from 'styled-components';


const Container = Styled.div`
  text-align: center;
  background-color: #304FFE;
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  &:hover{
    background-color #1E40FF;
  }
  &:active{
    box-shadow: inset 5px 5px 10px rgba(0,0,0,0.2);
  }
`;

const Label = Styled.div`
color: #FFFFFF;
font-size: 16px;
`;

interface Props {
  readonly label: string;
}

//export default Button;
export const Button = ({label}: Props) => {  //(props: Props)
    return (
        <Container>
            <Label>{label}</Label>
        </Container>
    );
}