import React from 'react';
import Styled from 'styled-components';

const InputBox = Styled.input`
flex: 1;
font-size: 16px;
width: 330px; //글자가 들어가도록 가로길이 수정 가능
padding: 10px 10px;  //input box의 여백
border-radius: 8px;
border: 1px solid #BDBDBD;
text-align: left;  //input text의 위치
outline:none;
`;

interface Props {
    readonly placeholder?: string;  //문자열 데이터이면서 필수 데이터가 아니므로 ?사용
    readonly onChange?: (text: string) => void;
}

export const Input = ({ placeholder, onChange }: Props) => {
    return (
        <InputBox
            placeholder={placeholder}
            onChange={(event) => {
                if (typeof onChange === 'function') {
                    onChange(event.target.value);
                }
            }} />
    );
};
