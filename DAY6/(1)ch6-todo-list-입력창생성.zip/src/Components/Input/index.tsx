import React from 'react';
import Styled from 'styled-components';

const InputBox = Styled.input`
flex: 1;
font-size: 16px;
padding: 10px 10px;
border-radius: 8px;
border: 1px solid #BDBDBD;
outline:none;
`;

export const Input = () => {
    return (
        <InputBox placeholder="할 일을 입력해 주세요" />
    );
}