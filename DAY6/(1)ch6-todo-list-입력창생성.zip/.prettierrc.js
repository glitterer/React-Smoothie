module.exports = {
    jsxBracketSameLine: true,
    single Quote: true,
    trailingComma: 'all',
    printWidth: 100,
};